USE [master]
GO
/****** Object:  Database [FloodRelief]    Script Date: 02/12/2022 5:38:53 pm ******/
CREATE DATABASE [FloodRelief]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'FloodRelief', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\FloodRelief.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'FloodRelief_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\FloodRelief_log.ldf' , SIZE = 73728KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [FloodRelief] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [FloodRelief].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [FloodRelief] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [FloodRelief] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [FloodRelief] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [FloodRelief] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [FloodRelief] SET ARITHABORT OFF 
GO
ALTER DATABASE [FloodRelief] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [FloodRelief] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [FloodRelief] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [FloodRelief] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [FloodRelief] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [FloodRelief] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [FloodRelief] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [FloodRelief] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [FloodRelief] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [FloodRelief] SET  ENABLE_BROKER 
GO
ALTER DATABASE [FloodRelief] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [FloodRelief] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [FloodRelief] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [FloodRelief] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [FloodRelief] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [FloodRelief] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [FloodRelief] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [FloodRelief] SET RECOVERY FULL 
GO
ALTER DATABASE [FloodRelief] SET  MULTI_USER 
GO
ALTER DATABASE [FloodRelief] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [FloodRelief] SET DB_CHAINING OFF 
GO
ALTER DATABASE [FloodRelief] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [FloodRelief] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [FloodRelief] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [FloodRelief] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'FloodRelief', N'ON'
GO
ALTER DATABASE [FloodRelief] SET QUERY_STORE = ON
GO
ALTER DATABASE [FloodRelief] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [FloodRelief]
GO
/****** Object:  Table [dbo].[CampReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CampReq](
	[RequestID] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[DistrictID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CashReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CashReq](
	[RequestID] [int] NOT NULL,
	[FamilyID] [int] NOT NULL,
	[Cash] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[District]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[District](
	[DistrictID] [int] NOT NULL,
	[DistrictName] [varchar](50) NOT NULL,
	[ProvinceID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[DistrictID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DistrictManager]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DistrictManager](
	[DManagerID] [int] NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[DistrictID] [int] NOT NULL,
	[ReportsTo] [int] NOT NULL,
	[Username] [varchar](50) NOT NULL,
	[Password] [varchar](50) NOT NULL,
 CONSTRAINT [PK__District__230C49B8D20C0875] PRIMARY KEY CLUSTERED 
(
	[DManagerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DoctorReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DoctorReq](
	[RequestID] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[CampID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Doctors]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Doctors](
	[DoctorID] [int] NOT NULL,
	[CampID] [int] NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
 CONSTRAINT [PK__Doctors__2DC00EDF2055CEAA] PRIMARY KEY CLUSTERED 
(
	[DoctorID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[EssentialReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[EssentialReq](
	[RequestID] [int] NOT NULL,
	[NoOfItems] [int] NOT NULL,
	[InventoryID] [int] NOT NULL,
	[EssentialName] [nchar](10) NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Essentials]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Essentials](
	[EssentialID] [int] NOT NULL,
	[EssentialName] [varchar](50) NOT NULL,
	[InventoryID] [int] NOT NULL,
	[Quantity] [int] NULL,
 CONSTRAINT [PK__Essentia__4CA99025C4A5F37D] PRIMARY KEY CLUSTERED 
(
	[EssentialID] ASC,
	[InventoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Families]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Families](
	[FamilyID] [int] NOT NULL,
	[DistrictID] [int] NOT NULL,
	[ShelterID] [int] NULL,
	[LivingConditions] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[FamilyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[FamilyLosses]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[FamilyLosses](
	[FamilyID] [int] NOT NULL,
	[DamageType] [varchar](50) NOT NULL,
	[MonetaryValue] [int] NOT NULL,
 CONSTRAINT [PK__FamilyLo__E556FDD14640D928] PRIMARY KEY CLUSTERED 
(
	[FamilyID] ASC,
	[DamageType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Inventory]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Inventory](
	[InventoryID] [int] NOT NULL,
	[DistrictID] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[InventoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[MedicalCamps]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MedicalCamps](
	[CampID] [int] NOT NULL,
	[DistrictID] [int] NOT NULL,
	[NoOfDoctors] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CampID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Patients]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Patients](
	[PatientID] [int] NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[CampID] [int] NULL,
	[Disease] [varchar](50) NOT NULL,
 CONSTRAINT [PK__Patients__970EC3463798B69E] PRIMARY KEY CLUSTERED 
(
	[PatientID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ProvinceManager]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ProvinceManager](
	[ManagerID] [int] NOT NULL,
	[ProvinceID] [int] NOT NULL,
	[Username] [varchar](50) NOT NULL,
	[Password] [varchar](50) NOT NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ManagerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Provinces]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Provinces](
	[ProvinceID] [int] NOT NULL,
	[ProvinceName] [varchar](50) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ProvinceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Requests]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Requests](
	[RequestID] [int] NOT NULL,
	[PManagerName] [varchar](50) NULL,
	[DManagerName] [varchar](50) NULL,
	[RequestType] [varchar](50) NOT NULL,
	[Date] [datetime] NOT NULL,
	[Status] [nchar](10) NULL,
 CONSTRAINT [PK__Requests__33A8519A3CD1F557] PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ShelterHomes]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ShelterHomes](
	[ShelterID] [int] NOT NULL,
	[DistrictID] [int] NOT NULL,
	[NoOfPeople] [int] NOT NULL,
	[Capacity] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ShelterID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[ShelterReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[ShelterReq](
	[RequestID] [int] NOT NULL,
	[Capacity] [int] NOT NULL,
	[DistrictID] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[RequestID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[CampReq]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[CampReq]  WITH CHECK ADD  CONSTRAINT [FK__CampReq__Request__797309D9] FOREIGN KEY([RequestID])
REFERENCES [dbo].[Requests] ([RequestID])
GO
ALTER TABLE [dbo].[CampReq] CHECK CONSTRAINT [FK__CampReq__Request__797309D9]
GO
ALTER TABLE [dbo].[CashReq]  WITH CHECK ADD FOREIGN KEY([FamilyID])
REFERENCES [dbo].[Families] ([FamilyID])
GO
ALTER TABLE [dbo].[CashReq]  WITH CHECK ADD  CONSTRAINT [FK__CashReq__Request__75A278F5] FOREIGN KEY([RequestID])
REFERENCES [dbo].[Requests] ([RequestID])
GO
ALTER TABLE [dbo].[CashReq] CHECK CONSTRAINT [FK__CashReq__Request__75A278F5]
GO
ALTER TABLE [dbo].[District]  WITH CHECK ADD FOREIGN KEY([ProvinceID])
REFERENCES [dbo].[Provinces] ([ProvinceID])
GO
ALTER TABLE [dbo].[DistrictManager]  WITH CHECK ADD  CONSTRAINT [FK__DistrictM__Distr__4AB81AF0] FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[DistrictManager] CHECK CONSTRAINT [FK__DistrictM__Distr__4AB81AF0]
GO
ALTER TABLE [dbo].[DistrictManager]  WITH CHECK ADD  CONSTRAINT [FK__DistrictM__Repor__02084FDA] FOREIGN KEY([ReportsTo])
REFERENCES [dbo].[ProvinceManager] ([ManagerID])
GO
ALTER TABLE [dbo].[DistrictManager] CHECK CONSTRAINT [FK__DistrictM__Repor__02084FDA]
GO
ALTER TABLE [dbo].[DoctorReq]  WITH CHECK ADD FOREIGN KEY([CampID])
REFERENCES [dbo].[MedicalCamps] ([CampID])
GO
ALTER TABLE [dbo].[DoctorReq]  WITH CHECK ADD  CONSTRAINT [FK__DoctorReq__Reque__71D1E811] FOREIGN KEY([RequestID])
REFERENCES [dbo].[Requests] ([RequestID])
GO
ALTER TABLE [dbo].[DoctorReq] CHECK CONSTRAINT [FK__DoctorReq__Reque__71D1E811]
GO
ALTER TABLE [dbo].[Doctors]  WITH CHECK ADD  CONSTRAINT [FK__Doctors__CampID__5AEE82B9] FOREIGN KEY([CampID])
REFERENCES [dbo].[MedicalCamps] ([CampID])
GO
ALTER TABLE [dbo].[Doctors] CHECK CONSTRAINT [FK__Doctors__CampID__5AEE82B9]
GO
ALTER TABLE [dbo].[EssentialReq]  WITH CHECK ADD FOREIGN KEY([InventoryID])
REFERENCES [dbo].[Inventory] ([InventoryID])
GO
ALTER TABLE [dbo].[EssentialReq]  WITH CHECK ADD FOREIGN KEY([InventoryID])
REFERENCES [dbo].[Inventory] ([InventoryID])
GO
ALTER TABLE [dbo].[EssentialReq]  WITH CHECK ADD  CONSTRAINT [FK__Essential__Reque__7F2BE32F] FOREIGN KEY([RequestID])
REFERENCES [dbo].[Requests] ([RequestID])
GO
ALTER TABLE [dbo].[EssentialReq] CHECK CONSTRAINT [FK__Essential__Reque__7F2BE32F]
GO
ALTER TABLE [dbo].[Essentials]  WITH CHECK ADD FOREIGN KEY([InventoryID])
REFERENCES [dbo].[Inventory] ([InventoryID])
GO
ALTER TABLE [dbo].[Essentials]  WITH CHECK ADD FOREIGN KEY([InventoryID])
REFERENCES [dbo].[Inventory] ([InventoryID])
GO
ALTER TABLE [dbo].[Families]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[Families]  WITH CHECK ADD FOREIGN KEY([ShelterID])
REFERENCES [dbo].[ShelterHomes] ([ShelterID])
GO
ALTER TABLE [dbo].[Families]  WITH CHECK ADD FOREIGN KEY([ShelterID])
REFERENCES [dbo].[ShelterHomes] ([ShelterID])
GO
ALTER TABLE [dbo].[FamilyLosses]  WITH CHECK ADD FOREIGN KEY([FamilyID])
REFERENCES [dbo].[Families] ([FamilyID])
GO
ALTER TABLE [dbo].[Inventory]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[Inventory]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[MedicalCamps]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[Patients]  WITH CHECK ADD  CONSTRAINT [FK__Patients__CampID__6477ECF3] FOREIGN KEY([CampID])
REFERENCES [dbo].[MedicalCamps] ([CampID])
GO
ALTER TABLE [dbo].[Patients] CHECK CONSTRAINT [FK__Patients__CampID__6477ECF3]
GO
ALTER TABLE [dbo].[ProvinceManager]  WITH CHECK ADD FOREIGN KEY([ProvinceID])
REFERENCES [dbo].[Provinces] ([ProvinceID])
GO
ALTER TABLE [dbo].[ShelterHomes]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[ShelterReq]  WITH CHECK ADD FOREIGN KEY([DistrictID])
REFERENCES [dbo].[District] ([DistrictID])
GO
ALTER TABLE [dbo].[ShelterReq]  WITH CHECK ADD  CONSTRAINT [FK__ShelterRe__Reque__7C4F7684] FOREIGN KEY([RequestID])
REFERENCES [dbo].[Requests] ([RequestID])
GO
ALTER TABLE [dbo].[ShelterReq] CHECK CONSTRAINT [FK__ShelterRe__Reque__7C4F7684]
GO
/****** Object:  StoredProcedure [dbo].[Approve]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Create procedure [dbo].[Approve]
@requestid int
AS
BEGIN
UPDATE [dbo].[Requests]
   SET 
      [Status] = 'Approved'
 WHERE RequestID = @requestid

END
GO
/****** Object:  StoredProcedure [dbo].[Approved Requests]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[Approved Requests]
@districtid int
AS
BEGIN
select * from Requests where DManagerName = (select FirstName+' '+LastName from DistrictManager 
where districtid=999) and Status = 'Approved'
order by [Date] desc
END
GO
/****** Object:  StoredProcedure [dbo].[CashRequest]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[CashRequest]
@districtid int
AS
BEGIN
select FamilyID,LivingConditions,ShelterID from Families where DistrictID=@districtid
END
GO
/****** Object:  StoredProcedure [dbo].[EssentialLoad]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[EssentialLoad]
@inventoryid int
AS
BEGIN
select EssentialID,EssentialName,Quantity from Essentials where InventoryID=@inventoryid
END
GO
/****** Object:  StoredProcedure [dbo].[EssentialRequest]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[EssentialRequest]
@districtid int
AS
BEGIN
select InventoryID,EssentialName,Quantity from Essentials where InventoryID in(select InventoryID from Inventory where DistrictID=@districtid)
END
GO
/****** Object:  StoredProcedure [dbo].[FloodReliefSearchorUpdate]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure  [dbo].[FloodReliefSearchorUpdate]
@mode varchar(50),
	@patientid int,
	@FirstName varchar(50),
	@LastName varchar(50),
	@CampID int,
	@Disease varchar(50)
	AS
	If @mode = 'Edit'
	BEGIN
	
UPDATE [dbo].[Patients]
   SET [CampID] = @CampID
      ,[Disease] = @Disease
      ,[FirstName] = @FirstName
      ,[LastName] = @LastName
 where patientid=@patientid
		   END

		   Else if @mode = 'Search'
		   BEGIN
		   Select * from Patients where patientid like '%'+@patientid+'%' and 
		   campid like '%'+@campid+'%' and disease like '%'+@disease+'%' and
		   firstname like '%'+@firstname+'%' and lastname like '%'+@lastname+'%'
		   END
GO
/****** Object:  StoredProcedure [dbo].[InsertCampReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertCampReq]
@districtid int,
@qty int
AS
BEGIN

DECLARE @id as int = (select max(RequestID)+1 from Requests)

INSERT INTO [dbo].[Requests]
           ([RequestID]
           ,[PManagerName]
           ,[DManagerName]
           ,[RequestType]
           ,[Date]
		   ,[Status])
     VALUES
           (@id
           ,(select FirstName+' '+LastName from ProvinceManager where managerid = (select ReportsTo from DistrictManager where districtid = @districtid))
           ,(select FirstName+' '+LastName from DistrictManager where districtid = @districtid)
           ,'Medical Camps'
           ,getdate()
		   ,'Pending')


INSERT INTO [dbo].[CampReq]
           ([RequestID]
           ,[Quantity]
           ,[DistrictID])
     VALUES
           (@id
           ,@qty
           ,@districtid)





END
GO
/****** Object:  StoredProcedure [dbo].[InsertCashReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertCashReq]
@districtid int,
@fid int,
@amount int
AS
BEGIN

DECLARE @id as int = (select max(RequestID)+1 from Requests)

INSERT INTO [dbo].[Requests]
           ([RequestID]
           ,[PManagerName]
           ,[DManagerName]
           ,[RequestType]
           ,[Date]
		   ,[Status])
     VALUES
           (@id
           ,(select FirstName+' '+LastName from ProvinceManager where managerid = (select ReportsTo from DistrictManager where districtid = @districtid))
           ,(select FirstName+' '+LastName from DistrictManager where districtid = @districtid)
           ,'Cash'
           ,getdate()
		   ,'Pending')



INSERT INTO [dbo].[CashReq]
           ([RequestID]
           ,[FamilyID]
           ,[Cash])
     VALUES
           (@id
           ,@fid
           ,@amount)




END
GO
/****** Object:  StoredProcedure [dbo].[InsertDoctorReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertDoctorReq]
@districtid int,
@qty int,
@campid  int
AS
BEGIN

DECLARE @id as int = (select max(RequestID)+1 from Requests)

INSERT INTO [dbo].[Requests]
           ([RequestID]
           ,[PManagerName]
           ,[DManagerName]
           ,[RequestType]
           ,[Date]
		   ,[Status])
     VALUES
           (@id
           ,(select FirstName+' '+LastName from ProvinceManager where managerid = (select ReportsTo from DistrictManager where districtid = @districtid))
           ,(select FirstName+' '+LastName from DistrictManager where districtid = @districtid)
           ,'Doctors'
           ,getdate()
		   ,'Pending')



INSERT INTO [dbo].[DoctorReq]
           ([RequestID]
           ,[Quantity]
           ,[CampID])
     VALUES
           (@id
           ,@qty
           ,@campid)




END
GO
/****** Object:  StoredProcedure [dbo].[InsertEssentialReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertEssentialReq]
@districtid int,
@essentialname varchar(50),
@inventoryid int,
@qty int
AS
BEGIN

DECLARE @id as int =(select max(RequestID)+1 from Requests)

INSERT INTO [dbo].[Requests]
           ([RequestID]
           ,[PManagerName]
           ,[DManagerName]
           ,[RequestType]
           ,[Date]
		   ,[Status])
     VALUES
           (@id
           ,(select FirstName+' '+LastName from ProvinceManager where managerid in (select ReportsTo from DistrictManager where districtid = @districtid))
           ,(select FirstName+' '+LastName from DistrictManager where districtid = @districtid)
           ,'Essentials'
           ,getdate()
		   ,'Pending')



INSERT INTO [dbo].[EssentialReq]
           ([RequestID]
           ,[NoOfItems]
           ,[InventoryID]
           ,[EssentialName])
     VALUES
           (@id
           ,@qty
           ,@inventoryid
           ,@essentialname)






END
GO
/****** Object:  StoredProcedure [dbo].[InsertShelterReq]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE Procedure [dbo].[InsertShelterReq]
@districtid int,
@capacity int


AS
BEGIN


DECLARE @id as int =(select max(RequestID)+1 from Requests)
INSERT INTO [dbo].[Requests]
           ([RequestID]
           ,[PManagerName]
           ,[DManagerName]
           ,[RequestType]
           ,[Date]
		   ,[Status])
     VALUES
           (@id
           ,(select FirstName+' '+LastName from ProvinceManager where managerid = (select ReportsTo from DistrictManager where districtid = @districtid))
           ,(select FirstName+' '+LastName from DistrictManager where districtid = @districtid)
           ,'Shelter Homes'
           ,getdate()
		   ,'Pending')


INSERT INTO [dbo].[ShelterReq]
           ([RequestID]
           ,[Capacity]
           ,[DistrictID])
     VALUES
           (@id
           ,@capacity
           ,@districtid)





END
GO
/****** Object:  StoredProcedure [dbo].[MedicalRequest]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[MedicalRequest]
@districtid int
AS
BEGIN
select CampID,NoOfDoctors from MedicalCamps where DistrictID=@districtid
END
GO
/****** Object:  StoredProcedure [dbo].[Pending Requests]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE procedure [dbo].[Pending Requests]
@districtid int
AS
BEGIN
select * from Requests where DManagerName = (select FirstName+' '+LastName from DistrictManager 
where districtid=999) and Status = 'Pending'
order by [Date] desc
END
GO
/****** Object:  StoredProcedure [dbo].[ShelterRequest]    Script Date: 02/12/2022 5:38:54 pm ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [dbo].[ShelterRequest]
@districtid int
AS
BEGIN
select ShelterID,NoOfPeople,Capacity from ShelterHomes where DistrictID=@districtid
END
GO
USE [master]
GO
ALTER DATABASE [FloodRelief] SET  READ_WRITE 
GO
