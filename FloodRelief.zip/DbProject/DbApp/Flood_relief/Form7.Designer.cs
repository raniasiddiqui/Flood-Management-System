﻿namespace Flood_relief
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cash_familyid = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.cash_amount = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.familyIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.livingConditionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelterIDDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cashRequestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.floodReliefDataSet11 = new Flood_relief.FloodReliefDataSet11();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.shelter_capacity = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.shelterIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noOfPeopleDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.capacityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shelterRequestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.floodReliefDataSet10 = new Flood_relief.FloodReliefDataSet10();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.item_essentialname = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.item_qty = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.item_inventoryid = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.inventoryIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.essentialNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.essentialRequestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.floodReliefDataSet9 = new Flood_relief.FloodReliefDataSet9();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.request_dr = new System.Windows.Forms.TabPage();
            this.doc_campid = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.doc_quantity_req = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.request_camp = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.camp_qty = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.campIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.noOfDoctorsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.medicalRequestBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.floodReliefDataSet7 = new Flood_relief.FloodReliefDataSet7();
            this.medicalRequestTableAdapter = new Flood_relief.FloodReliefDataSet7TableAdapters.MedicalRequestTableAdapter();
            this.essentialRequestTableAdapter = new Flood_relief.FloodReliefDataSet9TableAdapters.EssentialRequestTableAdapter();
            this.shelterRequestTableAdapter = new Flood_relief.FloodReliefDataSet10TableAdapters.ShelterRequestTableAdapter();
            this.cashRequestTableAdapter = new Flood_relief.FloodReliefDataSet11TableAdapters.CashRequestTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashRequestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet11)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shelterRequestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet10)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.essentialRequestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet9)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.request_dr.SuspendLayout();
            this.request_camp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRequestBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Desktop;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1151, 81);
            this.panel1.TabIndex = 25;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(1073, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 39);
            this.label1.TabIndex = 3;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label5.Location = new System.Drawing.Point(1344, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 39);
            this.label5.TabIndex = 2;
            this.label5.Text = "X";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(43, 37);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label6.Location = new System.Drawing.Point(468, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(246, 39);
            this.label6.TabIndex = 0;
            this.label6.Text = "Add Requests";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.tabControl4);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.dataGridView7);
            this.groupBox4.Location = new System.Drawing.Point(858, 88);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(280, 468);
            this.groupBox4.TabIndex = 24;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Family Aid";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage3);
            this.tabControl4.Location = new System.Drawing.Point(16, 241);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(240, 227);
            this.tabControl4.TabIndex = 7;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.cash_familyid);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.cash_amount);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(232, 201);
            this.tabPage3.TabIndex = 1;
            this.tabPage3.Text = "Request Aid";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cash_familyid
            // 
            this.cash_familyid.Location = new System.Drawing.Point(83, 17);
            this.cash_familyid.Name = "cash_familyid";
            this.cash_familyid.Size = new System.Drawing.Size(125, 20);
            this.cash_familyid.TabIndex = 34;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label11.Location = new System.Drawing.Point(31, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 33;
            this.label11.Text = "Family ID";
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Desktop;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.button5.Location = new System.Drawing.Point(81, 98);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(111, 24);
            this.button5.TabIndex = 32;
            this.button5.Text = "Confirm Request";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // cash_amount
            // 
            this.cash_amount.Location = new System.Drawing.Point(83, 56);
            this.cash_amount.Name = "cash_amount";
            this.cash_amount.Size = new System.Drawing.Size(125, 20);
            this.cash_amount.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label12.Location = new System.Drawing.Point(31, 59);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 13);
            this.label12.TabIndex = 30;
            this.label12.Text = "Amount";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label7.Location = new System.Drawing.Point(28, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(193, 20);
            this.label7.TabIndex = 2;
            this.label7.Text = "Families Most Affected";
            // 
            // dataGridView7
            // 
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.familyIDDataGridViewTextBoxColumn,
            this.livingConditionsDataGridViewTextBoxColumn,
            this.shelterIDDataGridViewTextBoxColumn1});
            this.dataGridView7.DataSource = this.cashRequestBindingSource;
            this.dataGridView7.Location = new System.Drawing.Point(16, 58);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.RowHeadersWidth = 51;
            this.dataGridView7.Size = new System.Drawing.Size(240, 150);
            this.dataGridView7.TabIndex = 0;
            this.dataGridView7.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView7_CellContentClick);
            // 
            // familyIDDataGridViewTextBoxColumn
            // 
            this.familyIDDataGridViewTextBoxColumn.DataPropertyName = "FamilyID";
            this.familyIDDataGridViewTextBoxColumn.HeaderText = "FamilyID";
            this.familyIDDataGridViewTextBoxColumn.Name = "familyIDDataGridViewTextBoxColumn";
            // 
            // livingConditionsDataGridViewTextBoxColumn
            // 
            this.livingConditionsDataGridViewTextBoxColumn.DataPropertyName = "LivingConditions";
            this.livingConditionsDataGridViewTextBoxColumn.HeaderText = "LivingConditions";
            this.livingConditionsDataGridViewTextBoxColumn.Name = "livingConditionsDataGridViewTextBoxColumn";
            // 
            // shelterIDDataGridViewTextBoxColumn1
            // 
            this.shelterIDDataGridViewTextBoxColumn1.DataPropertyName = "ShelterID";
            this.shelterIDDataGridViewTextBoxColumn1.HeaderText = "ShelterID";
            this.shelterIDDataGridViewTextBoxColumn1.Name = "shelterIDDataGridViewTextBoxColumn1";
            // 
            // cashRequestBindingSource
            // 
            this.cashRequestBindingSource.DataMember = "CashRequest";
            this.cashRequestBindingSource.DataSource = this.floodReliefDataSet11;
            // 
            // floodReliefDataSet11
            // 
            this.floodReliefDataSet11.DataSetName = "FloodReliefDataSet11";
            this.floodReliefDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tabControl3);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.dataGridView3);
            this.groupBox3.Location = new System.Drawing.Point(572, 88);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(280, 468);
            this.groupBox3.TabIndex = 23;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Shelter Homes";
            this.groupBox3.Enter += new System.EventHandler(this.groupBox3_Enter);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage1);
            this.tabControl3.Location = new System.Drawing.Point(16, 235);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(240, 227);
            this.tabControl3.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.shelter_capacity);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(232, 201);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "Request New Shelter";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // shelter_capacity
            // 
            this.shelter_capacity.Location = new System.Drawing.Point(72, 74);
            this.shelter_capacity.Name = "shelter_capacity";
            this.shelter_capacity.Size = new System.Drawing.Size(133, 20);
            this.shelter_capacity.TabIndex = 34;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label16.Location = new System.Drawing.Point(20, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 13);
            this.label16.TabIndex = 33;
            this.label16.Text = "Capacity";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Desktop;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.button4.Location = new System.Drawing.Point(72, 100);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(111, 24);
            this.button4.TabIndex = 32;
            this.button4.Text = "Confirm Request";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label3.Location = new System.Drawing.Point(39, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(206, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Shelters with Space Left";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.shelterIDDataGridViewTextBoxColumn,
            this.noOfPeopleDataGridViewTextBoxColumn,
            this.capacityDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.shelterRequestBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(27, 58);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(240, 150);
            this.dataGridView3.TabIndex = 1;
            // 
            // shelterIDDataGridViewTextBoxColumn
            // 
            this.shelterIDDataGridViewTextBoxColumn.DataPropertyName = "ShelterID";
            this.shelterIDDataGridViewTextBoxColumn.HeaderText = "ShelterID";
            this.shelterIDDataGridViewTextBoxColumn.Name = "shelterIDDataGridViewTextBoxColumn";
            // 
            // noOfPeopleDataGridViewTextBoxColumn
            // 
            this.noOfPeopleDataGridViewTextBoxColumn.DataPropertyName = "NoOfPeople";
            this.noOfPeopleDataGridViewTextBoxColumn.HeaderText = "NoOfPeople";
            this.noOfPeopleDataGridViewTextBoxColumn.Name = "noOfPeopleDataGridViewTextBoxColumn";
            // 
            // capacityDataGridViewTextBoxColumn
            // 
            this.capacityDataGridViewTextBoxColumn.DataPropertyName = "Capacity";
            this.capacityDataGridViewTextBoxColumn.HeaderText = "Capacity";
            this.capacityDataGridViewTextBoxColumn.Name = "capacityDataGridViewTextBoxColumn";
            // 
            // shelterRequestBindingSource
            // 
            this.shelterRequestBindingSource.DataMember = "ShelterRequest";
            this.shelterRequestBindingSource.DataSource = this.floodReliefDataSet10;
            // 
            // floodReliefDataSet10
            // 
            this.floodReliefDataSet10.DataSetName = "FloodReliefDataSet10";
            this.floodReliefDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl2);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.dataGridView4);
            this.groupBox2.Location = new System.Drawing.Point(286, 88);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(280, 468);
            this.groupBox2.TabIndex = 22;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inventory";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Location = new System.Drawing.Point(16, 235);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(240, 227);
            this.tabControl2.TabIndex = 5;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.item_essentialname);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.item_qty);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.item_inventoryid);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(232, 201);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Request Item";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // item_essentialname
            // 
            this.item_essentialname.Location = new System.Drawing.Point(93, 62);
            this.item_essentialname.Name = "item_essentialname";
            this.item_essentialname.Size = new System.Drawing.Size(125, 20);
            this.item_essentialname.TabIndex = 33;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label15.Location = new System.Drawing.Point(7, 65);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(80, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "Essential Name";
            // 
            // item_qty
            // 
            this.item_qty.Location = new System.Drawing.Point(93, 96);
            this.item_qty.Name = "item_qty";
            this.item_qty.Size = new System.Drawing.Size(125, 20);
            this.item_qty.TabIndex = 31;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label14.Location = new System.Drawing.Point(7, 97);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 13);
            this.label14.TabIndex = 30;
            this.label14.Text = "Quantity";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Desktop;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.button1.Location = new System.Drawing.Point(59, 135);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 24);
            this.button1.TabIndex = 29;
            this.button1.Text = "Confirm Request";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // item_inventoryid
            // 
            this.item_inventoryid.Location = new System.Drawing.Point(93, 30);
            this.item_inventoryid.Name = "item_inventoryid";
            this.item_inventoryid.Size = new System.Drawing.Size(125, 20);
            this.item_inventoryid.TabIndex = 28;
            this.item_inventoryid.TextChanged += new System.EventHandler(this.item_quantity_req_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label10.Location = new System.Drawing.Point(7, 33);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(65, 13);
            this.label10.TabIndex = 27;
            this.label10.Text = "Inventory ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label4.Location = new System.Drawing.Point(26, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(219, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Items running out of stock";
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.inventoryIDDataGridViewTextBoxColumn,
            this.essentialNameDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.essentialRequestBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(16, 58);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(240, 150);
            this.dataGridView4.TabIndex = 0;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // inventoryIDDataGridViewTextBoxColumn
            // 
            this.inventoryIDDataGridViewTextBoxColumn.DataPropertyName = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.HeaderText = "InventoryID";
            this.inventoryIDDataGridViewTextBoxColumn.Name = "inventoryIDDataGridViewTextBoxColumn";
            // 
            // essentialNameDataGridViewTextBoxColumn
            // 
            this.essentialNameDataGridViewTextBoxColumn.DataPropertyName = "EssentialName";
            this.essentialNameDataGridViewTextBoxColumn.HeaderText = "EssentialName";
            this.essentialNameDataGridViewTextBoxColumn.Name = "essentialNameDataGridViewTextBoxColumn";
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "Quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            // 
            // essentialRequestBindingSource
            // 
            this.essentialRequestBindingSource.DataMember = "EssentialRequest";
            this.essentialRequestBindingSource.DataSource = this.floodReliefDataSet9;
            // 
            // floodReliefDataSet9
            // 
            this.floodReliefDataSet9.DataSetName = "FloodReliefDataSet9";
            this.floodReliefDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tabControl1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Location = new System.Drawing.Point(0, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(280, 468);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Medical";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.request_dr);
            this.tabControl1.Controls.Add(this.request_camp);
            this.tabControl1.Location = new System.Drawing.Point(13, 235);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(240, 227);
            this.tabControl1.TabIndex = 4;
            // 
            // request_dr
            // 
            this.request_dr.Controls.Add(this.doc_campid);
            this.request_dr.Controls.Add(this.label13);
            this.request_dr.Controls.Add(this.button3);
            this.request_dr.Controls.Add(this.doc_quantity_req);
            this.request_dr.Controls.Add(this.label9);
            this.request_dr.Location = new System.Drawing.Point(4, 22);
            this.request_dr.Name = "request_dr";
            this.request_dr.Padding = new System.Windows.Forms.Padding(3);
            this.request_dr.Size = new System.Drawing.Size(232, 201);
            this.request_dr.TabIndex = 1;
            this.request_dr.Text = "Request Doctors";
            this.request_dr.UseVisualStyleBackColor = true;
            // 
            // doc_campid
            // 
            this.doc_campid.Location = new System.Drawing.Point(72, 23);
            this.doc_campid.Name = "doc_campid";
            this.doc_campid.Size = new System.Drawing.Size(125, 20);
            this.doc_campid.TabIndex = 32;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label13.Location = new System.Drawing.Point(20, 30);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(48, 13);
            this.label13.TabIndex = 31;
            this.label13.Text = "Camp ID";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Desktop;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.button3.Location = new System.Drawing.Point(72, 96);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(111, 24);
            this.button3.TabIndex = 30;
            this.button3.Text = "Confirm Request";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // doc_quantity_req
            // 
            this.doc_quantity_req.Location = new System.Drawing.Point(72, 58);
            this.doc_quantity_req.Name = "doc_quantity_req";
            this.doc_quantity_req.Size = new System.Drawing.Size(125, 20);
            this.doc_quantity_req.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label9.Location = new System.Drawing.Point(20, 65);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 26;
            this.label9.Text = "Quantity";
            // 
            // request_camp
            // 
            this.request_camp.BackColor = System.Drawing.Color.Transparent;
            this.request_camp.Controls.Add(this.button2);
            this.request_camp.Controls.Add(this.camp_qty);
            this.request_camp.Controls.Add(this.label8);
            this.request_camp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.request_camp.ForeColor = System.Drawing.SystemColors.Desktop;
            this.request_camp.Location = new System.Drawing.Point(4, 22);
            this.request_camp.Name = "request_camp";
            this.request_camp.Padding = new System.Windows.Forms.Padding(3);
            this.request_camp.Size = new System.Drawing.Size(232, 201);
            this.request_camp.TabIndex = 0;
            this.request_camp.Text = "Request New Camp";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Desktop;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.button2.Location = new System.Drawing.Point(60, 96);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 24);
            this.button2.TabIndex = 26;
            this.button2.Text = "Confirm Request";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // camp_qty
            // 
            this.camp_qty.Location = new System.Drawing.Point(60, 26);
            this.camp_qty.Name = "camp_qty";
            this.camp_qty.Size = new System.Drawing.Size(125, 24);
            this.camp_qty.TabIndex = 25;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label8.Location = new System.Drawing.Point(8, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Quantity";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label2.Location = new System.Drawing.Point(6, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 40);
            this.label2.TabIndex = 3;
            this.label2.Text = "Camps with high Doctor to \r\nPatient Ratio";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.campIDDataGridViewTextBoxColumn,
            this.noOfDoctorsDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.medicalRequestBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(13, 69);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(240, 150);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // campIDDataGridViewTextBoxColumn
            // 
            this.campIDDataGridViewTextBoxColumn.DataPropertyName = "CampID";
            this.campIDDataGridViewTextBoxColumn.HeaderText = "CampID";
            this.campIDDataGridViewTextBoxColumn.Name = "campIDDataGridViewTextBoxColumn";
            // 
            // noOfDoctorsDataGridViewTextBoxColumn
            // 
            this.noOfDoctorsDataGridViewTextBoxColumn.DataPropertyName = "NoOfDoctors";
            this.noOfDoctorsDataGridViewTextBoxColumn.HeaderText = "NoOfDoctors";
            this.noOfDoctorsDataGridViewTextBoxColumn.Name = "noOfDoctorsDataGridViewTextBoxColumn";
            // 
            // medicalRequestBindingSource
            // 
            this.medicalRequestBindingSource.DataMember = "MedicalRequest";
            this.medicalRequestBindingSource.DataSource = this.floodReliefDataSet7;
            // 
            // floodReliefDataSet7
            // 
            this.floodReliefDataSet7.DataSetName = "FloodReliefDataSet7";
            this.floodReliefDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // medicalRequestTableAdapter
            // 
            this.medicalRequestTableAdapter.ClearBeforeFill = true;
            // 
            // essentialRequestTableAdapter
            // 
            this.essentialRequestTableAdapter.ClearBeforeFill = true;
            // 
            // shelterRequestTableAdapter
            // 
            this.shelterRequestTableAdapter.ClearBeforeFill = true;
            // 
            // cashRequestTableAdapter
            // 
            this.cashRequestTableAdapter.ClearBeforeFill = true;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1136, 556);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabControl4.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cashRequestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet11)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shelterRequestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet10)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.essentialRequestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet9)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.request_dr.ResumeLayout(false);
            this.request_dr.PerformLayout();
            this.request_camp.ResumeLayout(false);
            this.request_camp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.medicalRequestBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.floodReliefDataSet7)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox cash_amount;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox item_inventoryid;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage request_dr;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox doc_quantity_req;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage request_camp;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox camp_qty;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn campIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noOfDoctorsDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource medicalRequestBindingSource;
        private FloodReliefDataSet7 floodReliefDataSet7;
        private FloodReliefDataSet7TableAdapters.MedicalRequestTableAdapter medicalRequestTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn familyIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn livingConditionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn shelterIDDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource cashRequestBindingSource;
        private FloodReliefDataSet11 floodReliefDataSet11;
        private System.Windows.Forms.DataGridViewTextBoxColumn shelterIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn noOfPeopleDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn capacityDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource shelterRequestBindingSource;
        private FloodReliefDataSet10 floodReliefDataSet10;
        private System.Windows.Forms.DataGridViewTextBoxColumn inventoryIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn essentialNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource essentialRequestBindingSource;
        private FloodReliefDataSet9 floodReliefDataSet9;
        private System.Windows.Forms.TextBox doc_campid;
        private System.Windows.Forms.Label label13;
        private FloodReliefDataSet9TableAdapters.EssentialRequestTableAdapter essentialRequestTableAdapter;
        private FloodReliefDataSet10TableAdapters.ShelterRequestTableAdapter shelterRequestTableAdapter;
        private FloodReliefDataSet11TableAdapters.CashRequestTableAdapter cashRequestTableAdapter;
        private System.Windows.Forms.TextBox item_essentialname;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox item_qty;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox cash_familyid;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox shelter_capacity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button4;
    }
}