﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }
        


        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Hide();
            d_shelter f2 = new d_shelter();
            f2.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            d_inventory f2 = new d_inventory();
            f2.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

            this.Hide();
            d_medical f2 = new d_medical();
            
            f2.Show();
            
        }

        private void label6_Click(object sender, EventArgs e)
        {
            this.Hide();
            d_family f2 = new d_family();
            f2.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 f2 = new Form7();
            f2.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 f2 = new Form8();
            f2.Show();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            d_medical f2 = new d_medical();
            f2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {
            //this.Close();
            //Login f2 = new Login();
            //f2.Show();
        }
    }
}
