﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class Form10 : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public Form10()
        {
            InitializeComponent();
        }

        private int Verify()
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            string sql = "select Provinceid from ProvinceManager where Username = @Username and password = @password";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@UserName", p_username.Text);
            cm.Parameters.AddWithValue("@Password", p_password.Text);
            int result = (int)cm.ExecuteScalar();

            //cm.Parameters.AddWithValue("@Campid", Convert.ToInt32(campid.Text));


            cm.ExecuteNonQuery();
            con.Close();
            return result;

        }

        private void p_username_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int s = Verify();


            if (s.ToString() == null)
            {
                MessageBox.Show("Incorrect username or password");
            }
            else
            {
                Global.GlobalVar = s;
                this.Hide();
                Form11 f2 = new Form11();


                f2.Show();
            }
        }
    }
}
