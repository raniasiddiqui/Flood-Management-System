﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class add_camp : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public add_camp()
        {
            InitializeComponent();
        }

        private void InsertCamp()
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            string sql = "INSERT INTO [dbo].[MedicalCamps]\r\n           ([CampID]\r\n           ,[DistrictID]\r\n           ,[NoOfDoctors])\r\n     VALUES\r\n           ((select max(CampID)+1 from MedicalCamps)\r\n           ,@districtid      ,@NoOfDoctors)";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@Districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@NoOfDoctors", Convert.ToInt32(qty.Text));


            cm.ExecuteNonQuery();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            InsertCamp();
            qty.Text = "";
            this.Close();
            d_medical f2 = new d_medical();
            f2.Show();
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
