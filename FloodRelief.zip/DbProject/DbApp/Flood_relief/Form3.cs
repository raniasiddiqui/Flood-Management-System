﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class d_shelter : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public d_shelter()
        {
            InitializeComponent();
        }
        private void LoadShelterData()
        {
            con.Open();
            string sql = "select ShelterID,NoOfPeople,Capacity from ShelterHomes where districtid =@districtid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = d;
        }
        private void DeleteShelter(int shelterid)
        {
            con.Open();
            

            string sql = "Update Families set shelterid = NULL where shelterid = @shelterid        DELETE FROM ShelterHomes WHERE shelterid=@shelterid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@shelterid", shelterid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f2 = new Form1();
            f2.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Form6 f2 = new Form6();
            f2.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteShelter(n);
                LoadShelterData();
                



            }
            else if (e.ColumnIndex == dataGridView1.Columns["dataGridViewEditButton"].Index && e.RowIndex >= 0)
            {
                shelter_id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                no_of_people.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                capacity.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            }
        }

        

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            
            
        }

        private void d_shelter_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'floodReliefDataSet14.ShelterHomes' table. You can move, or remove it, as needed.
            this.shelterHomesTableAdapter.Fill(this.floodReliefDataSet14.ShelterHomes);
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            var editButton = new DataGridViewButtonColumn();
            editButton.Name = "dataGridViewEditButton";
            editButton.HeaderText = "Edit";
            editButton.Text = "Edit";
            editButton.UseColumnTextForButtonValue = true;

            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;

            LoadShelterData();
            dataGridView1.Columns.Add(editButton);
            dataGridView1.Columns.Add(deleteButton);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "Select * from ShelterHomes where shelterid like '%'+@shelterid+'%' and \r\n\t\t   NoOfPeople like '%'+@NoOfPeople+'%' and capacity like '%'+@capacity+'%' and districtid = @districtid";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");
            cm.Parameters.AddWithValue("@shelterid", shelter_id.Text.Trim());
            cm.Parameters.AddWithValue("@NoOfPeople", no_of_people.Text);
            cm.Parameters.AddWithValue("@capacity", capacity.Text);
           cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da4 = new SqlDataAdapter(cm);
            DataTable d4 = new DataTable();
            da4.Fill(d4);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = null;
            //dataGridView3.Columns.Remove("dataGridViewDeleteButton3");
            //dataGridView3.Columns.Remove("dataGridViewEditButton3");

            dataGridView1.DataSource = d4;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            shelter_id.Text = "";
            no_of_people.Text = "";
            capacity.Text = "";
            LoadShelterData();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "UPDATE [dbo].[ShelterHomes]\r\n   SET      [Capacity] = @capacity\r\n      ,[NoOfPeople] = @NoOfPeople\r\n WHERE shelterid=@shelterid";
            cm = new SqlCommand(sql, con);

            cm.Parameters.AddWithValue("@shelterid", Convert.ToInt32(shelter_id.Text.Trim()));
            cm.Parameters.AddWithValue("@NoOfPeople", Convert.ToInt32(no_of_people.Text.Trim()));
            cm.Parameters.AddWithValue("@Capacity", Convert.ToInt32(capacity.Text.Trim()));

            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadShelterData();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            shelter_id.Text = "";
            no_of_people.Text = "";
            capacity.Text = "";
            LoadShelterData();
        }
    }
}
