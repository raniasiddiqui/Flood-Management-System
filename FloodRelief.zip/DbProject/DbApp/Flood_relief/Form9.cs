﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Flood_relief
{
    public partial class Form9 : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public Form9()
        {
            InitializeComponent();
        }

        private int Verify()
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            string sql = "select districtid from DistrictManager where Username = @Username and password = @password";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@UserName", d_username.Text);
            cm.Parameters.AddWithValue("@Password", d_password.Text);
            int result = (int)cm.ExecuteScalar();

            //cm.Parameters.AddWithValue("@Campid", Convert.ToInt32(campid.Text));


            cm.ExecuteNonQuery();
            con.Close();
            return result;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int s = Verify();

            
            if (s.ToString()==null)
            {
                MessageBox.Show("Incorrect username or password");
            }
            else
            {
                Global.GlobalVar = s;
                this.Close();
                Form1 f2 = new Form1();
                
                
                f2.Show();
            }

            

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
