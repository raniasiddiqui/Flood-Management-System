﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class add_family : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public add_family()
        {
            InitializeComponent();
        }
        private void InsertFamily()
        {
            string sql = "INSERT INTO [dbo].[Families]\r\n           ([FamilyID]\r\n           ,[DistrictID]\r\n           ,[ShelterID]\r\n           ,[LivingConditions])\r\n     VALUES\r\n           ((select max(FamilyID)+1 from Families)\r\n           ,@districtid\r\n           ,@shelterid        ,@livingconditions)";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@shelterid", Convert.ToInt32(shelter_id.Text));
            cm.Parameters.AddWithValue("@livingconditions", Global.GlobalVar3);
            //cm.Parameters.AddWithValue("@shelterid", 804);


            cm.ExecuteNonQuery();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertFamily();
            shelter_id.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            
            this.Close();
            //d_family f2 = new d_family();
            //f2.Show();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar3 = 1;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar3 = 2;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar3 = 3;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar3 = 4;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar3 = 5;
        }

        private void shelterid_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
