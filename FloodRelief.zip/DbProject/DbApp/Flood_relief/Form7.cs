﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class Form7 : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public Form7()
        {
            InitializeComponent();
        }
        private void LoadMedical()
        {
            con.Open();
            string sql = "MedicalRequest";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView2.DataSource = d;
        }

        private void LoadEssential()
        {
            con.Open();
            string sql = "EssentialRequest";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da2 = new SqlDataAdapter(cm);
            DataTable d2 = new DataTable();
            da2.Fill(d2);
            cm.Dispose();
            con.Close();
            dataGridView4.DataSource = d2;
        }

        private void LoadShelter()
        {
            con.Open();
            string sql = "ShelterRequest";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataTable d3 = new DataTable();
            da3.Fill(d3);
            cm.Dispose();
            con.Close();
            dataGridView3.DataSource = d3;
        }

        private void LoadCash()
        {
            con.Open();
            string sql = "CashRequest";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da4 = new SqlDataAdapter(cm);
            DataTable d4 = new DataTable();
            da4.Fill(d4);
            cm.Dispose();
            con.Close();
            dataGridView7.DataSource = d4;
        }

        private void InsertDoctorReq()
        {
            
            
            con.Open();
            string sql = "InsertDoctorReq";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@qty", Convert.ToInt32(doc_quantity_req.Text));
            cm.Parameters.AddWithValue("@campid", Convert.ToInt32(doc_campid.Text));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void InsertCampReq()
        {


            con.Open();
            string sql = "InsertCampReq";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@qty", Convert.ToInt32(camp_qty.Text));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void InsertCashReq()
        {


            con.Open();
            string sql = "InsertCashReq";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@fid", Convert.ToInt32(cash_familyid.Text));
            cm.Parameters.AddWithValue("@amount", Convert.ToInt32(cash_amount.Text));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void InsertShelterReq()
        {


            con.Open();
            string sql = "InsertShelterReq";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@capacity", Convert.ToInt32(shelter_capacity.Text));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void InsertEssentialReq()
        {


            con.Open();
            string sql = "InsertEssentialReq";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@essentialname", item_essentialname.Text);
            cm.Parameters.AddWithValue("@inventoryid", Convert.ToInt32(item_inventoryid.Text));
            cm.Parameters.AddWithValue("@qty", Convert.ToInt32(item_qty.Text));
            cm.ExecuteNonQuery();
            con.Close();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView2.CurrentRow.Index != -1)
            {
                if (tabControl1.SelectedTab == request_dr)
                {
                    doc_campid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                    //doc_quantity_req.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                }
                else if (tabControl1.SelectedTab == request_camp)
                {
                    camp_qty.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                    
                }
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            LoadMedical();
            LoadEssential();
            LoadShelter();
            LoadCash();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 f2 = new Form1();
            f2.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void item_quantity_req_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView4.CurrentRow.Index != -1)
            {
                
                item_inventoryid.Text = dataGridView4.CurrentRow.Cells[0].Value.ToString();
                item_essentialname.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
                

            }
        }

        private void dataGridView7_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView7.CurrentRow.Index != -1)
            {

                cash_familyid.Text = dataGridView7.CurrentRow.Cells[0].Value.ToString();
                


            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            InsertCampReq();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            InsertDoctorReq();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertEssentialReq();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            InsertShelterReq();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            InsertCashReq();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
    }
}
