﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Flood_relief
{
    public partial class add_doctor : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public add_doctor()
        {
            InitializeComponent();
        }

        private void InsertDoctor()
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            string sql = "INSERT INTO [dbo].[Doctors]\r\n           ([DoctorID]\r\n           ,[CampID]\r\n           ,[FirstName]\r\n           ,[LastName])\r\n     VALUES\r\n           ((select max(DoctorID)+1 from Doctors)\r\n           ,@Campid\r\n           ,@FirstName\r\n           ,@LastName)\r\n\r\n\t\t   Update MedicalCamps set NoOfDoctors = NoOfDoctors + 1 where CampID = @campid;";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@FirstName", doctor_fname.Text);
            cm.Parameters.AddWithValue("@LastName", lname.Text);
            cm.Parameters.AddWithValue("@Campid", Convert.ToInt32(campid.Text));


            cm.ExecuteNonQuery();
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void add_doctor_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertDoctor();
            doctor_fname.Text = "";
            lname.Text = "";
            campid.Text = "";
            this.Close();
            d_medical f2 = new d_medical();
            f2.Show();
        }
    }
}
