﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class Form6 : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public Form6()
        {
            InitializeComponent();
        }

        private void InsertShelter()
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            string sql = "INSERT INTO [dbo].[ShelterHomes]           ([ShelterID]          ,[DistrictID]          ,[NoOfPeople],[Capacity] )    VALUES         ((select max(ShelterID)+1 from ShelterHomes)  ,@Districtid    ,@NoOfPeople,@Capacity)";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@Districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@NoOfPeople", Convert.ToInt32(no_of_ppl_registered.Text));
            cm.Parameters.AddWithValue("@Capacity", Convert.ToInt32(capacity.Text));

            cm.ExecuteNonQuery();
            con.Close();
        }
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertShelter();
            capacity.Text = "";
            no_of_ppl_registered.Text = "";
            this.Close();
            d_shelter f2 = new d_shelter();
            f2.Show();
        }
    }
}
