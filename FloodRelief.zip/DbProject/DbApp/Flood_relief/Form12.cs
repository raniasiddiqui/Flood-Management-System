﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class Form12 : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public Form12()
        {
            InitializeComponent();
        }

        private void Load_PendingRequests()
        {
            
            con.Open();
            string sql = "select * from Requests where status = 'Pending'";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da6 = new SqlDataAdapter(cm);
            DataTable d6 = new DataTable();
            da6.Fill(d6);
            cm.Dispose();
            con.Close();
            //dataGridView1.DataSource = null;
            //dataGridView1.Columns.Remove("dataGridViewDeleteButton");
            //dataGridView1.Columns.Remove("dataGridViewEditButton");

            dataGridView1.DataSource = d6;
        }

        private void Load_ApprovedRequests()
        {

            con.Open();
            string sql = "select * from Requests where status = 'Approved'";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;

            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            //dataGridView1.DataSource = null;
            //dataGridView1.Columns.Remove("dataGridViewDeleteButton");
            //dataGridView1.Columns.Remove("dataGridViewEditButton");

            dataGridView3.DataSource = d;
        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form11 f2 = new Form11();
            f2.Show();

        }

        private void Form12_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'floodReliefDataSet13.Requests' table. You can move, or remove it, as needed.

            this.requestsTableAdapter.Fill(this.floodReliefDataSet13.Requests);
            Load_PendingRequests(); 
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.RowHeadersVisible = false;
            dataGridView3.BackgroundColor = Color.White;
            dataGridView3.RowHeadersVisible = false;
            dataGridView4.BackgroundColor = Color.White;
            dataGridView4.RowHeadersVisible = false;


            var ViewDetailsButton = new DataGridViewButtonColumn();
            ViewDetailsButton.Name = "dataGridViewDetailsButton";
            ViewDetailsButton.HeaderText = "View Details";
            ViewDetailsButton.Text = "View Details";
            ViewDetailsButton.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(ViewDetailsButton);

            var ApproveButton = new DataGridViewButtonColumn();
            ApproveButton.Name = "dataGridApproveButton";
            ApproveButton.HeaderText = "Approve";
            ApproveButton.Text = "Approve";
            ApproveButton.UseColumnTextForButtonValue = true;
            dataGridView1.Columns.Add(ApproveButton);

            Load_ApprovedRequests();
            var ViewDetailsButton2 = new DataGridViewButtonColumn();
            ViewDetailsButton2.Name = "dataGridViewDetailsButton2";
            ViewDetailsButton2.HeaderText = "View Details";
            ViewDetailsButton2.Text = "View Details";
            ViewDetailsButton2.UseColumnTextForButtonValue = true;
            dataGridView3.Columns.Add(ViewDetailsButton2);

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDetailsButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                //string requestid = data.Cells[3].Value.ToString();
                //MessageBox.Show(requestid);

                if (data.Cells[3].Value.ToString() == "Essentials")
                {
                    con.Open();
                    string sql = "select * from EssentialReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView2.DataSource = d2;
                }

                else if (data.Cells[3].Value.ToString() == "Doctors")
                {
                    con.Open();
                    string sql = "select * from DoctorReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView2.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Cash")
                {
                    con.Open();
                    string sql = "select * from CashReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView2.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Medical Camps")
                {
                    con.Open();
                    string sql = "select * from CampReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView2.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Shelter Homes")
                {
                    con.Open();
                    string sql = "select * from ShelterReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView2.DataSource = d2;
                }




            }
            else if (e.ColumnIndex == dataGridView1.Columns["dataGridApproveButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                con.Open();
                string sql = "Approve";
                cm = new SqlCommand(sql, con);
                cm.CommandType = CommandType.StoredProcedure;
                cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                cm.ExecuteNonQuery();
                cm.Dispose();
                con.Close();
                Load_ApprovedRequests();
                Load_PendingRequests();
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dataGridView3_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView3.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView3.Columns["dataGridViewDetailsButton2"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView3.Rows[e.RowIndex];
                //string requestid = data.Cells[3].Value.ToString();
                //MessageBox.Show(requestid);

                if (data.Cells[3].Value.ToString() == "Essentials")
                {
                    con.Open();
                    string sql = "select * from EssentialReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView4.DataSource = d2;
                }

                else if (data.Cells[3].Value.ToString() == "Doctors")
                {
                    con.Open();
                    string sql = "select * from DoctorReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView4.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Cash")
                {
                    con.Open();
                    string sql = "select * from CashReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView4.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Medical Camps")
                {
                    con.Open();
                    string sql = "select * from CampReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView4.DataSource = d2;
                }
                else if (data.Cells[3].Value.ToString() == "Shelter Homes")
                {
                    con.Open();
                    string sql = "select * from ShelterReq where requestid=@requestid";
                    cm = new SqlCommand(sql, con);
                    cm.Parameters.AddWithValue("@requestid", Convert.ToInt32(data.Cells[0].Value));
                    SqlDataAdapter da2 = new SqlDataAdapter(cm);
                    DataTable d2 = new DataTable();
                    da2.Fill(d2);
                    cm.Dispose();
                    con.Close();
                    dataGridView4.DataSource = d2;
                }




            }
            
        }
    }
}
