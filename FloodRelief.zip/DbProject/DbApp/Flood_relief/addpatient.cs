﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Flood_relief
{
    public partial class addpatient : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public addpatient()
        {
            InitializeComponent();
        }
        private void InsertPatient()
        {
            string sql = "INSERT INTO [dbo].[Patients]\r\n           ([PatientID]\r\n           ,[FirstName]\r\n           ,[LastName]\r\n           ,[CampID]\r\n           ,[Disease])\r\n     VALUES\r\n           ((select max(PatientID)+1 from Patients)\r\n           ,@FirstName\r\n           ,@LastName\r\n           ,@CampID\r\n           ,@Disease)";
            con.Open();
            cm = new SqlCommand(sql, con);
            // Specify the value for the parameters.
            cm.Parameters.AddWithValue("@FirstName", patient_fname.Text);
            cm.Parameters.AddWithValue("@LastName", patient_lname.Text);
            cm.Parameters.AddWithValue("@Campid", Convert.ToInt32(campid.Text));
            cm.Parameters.AddWithValue("@Disease", disease.Text);


            cm.ExecuteNonQuery();
            con.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // TODO: Complete the function InsertOrder
            // Sql query to insert a new order.
            InsertPatient();
            patient_fname.Text = "";
            patient_fname.Text = "";
            
            campid.Text = "";
            disease.Text = "";
            this.Close();
            d_medical f2 = new d_medical();
            f2.Show();

        }
    }
}
