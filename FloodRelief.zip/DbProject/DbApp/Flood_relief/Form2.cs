﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{



    public partial class d_medical : Form
    {


        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();

        public d_medical()
        {
            InitializeComponent();
        }
       

        private void LoadMedicalCamps()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            con.Open();
            string sql = "select * from MedicalCamps where districtid =@districtid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = d;


        }


        private void LoadDoctors()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            con.Open();
            string sql = "select * from Doctors where campid in (select campid from MedicalCamps where districtid=@districtid)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da2 = new SqlDataAdapter(cm);
            DataTable d2 = new DataTable();
            da2.Fill(d2);
            cm.Dispose();
            con.Close();
            dataGridView2.DataSource = d2;


        }

        private void LoadPatients()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            con.Open();
            string sql = "select * from Patients where campid in (select campid from MedicalCamps where districtid=@districtid)";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da3 = new SqlDataAdapter(cm);
            DataTable d3 = new DataTable();
            da3.Fill(d3);
            cm.Dispose();
            con.Close();
            dataGridView3.DataSource = d3;


        }

        private void DeleteMedicalCamp(int campid)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "Update Patients set campid = NULL where campid = @campid\r\nUpdate Doctors set campid = NULL where campid = @campid\r\n                DELETE FROM MedicalCamps WHERE campid=@campid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@campid", campid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();

        }

        private void DeleteDoctors(int doctorid)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "Update MedicalCamps set NoOfDoctors = NoOfDoctors - 1 where campid = (select campid from doctors where doctorid = @doctorid)\r\nDELETE FROM Doctors WHERE doctorid=@doctorid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@doctorid", doctorid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();

        }

        private void DeletePatient(int patientid)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "DELETE FROM Patients WHERE patientid=@patientid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@patientid", patientid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();

        }




        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'floodReliefDataSet2.Patients' table. You can move, or remove it, as needed.
            this.patientsTableAdapter.Fill(this.floodReliefDataSet2.Patients);
            // TODO: This line of code loads data into the 'floodReliefDataSet1.Doctors' table. You can move, or remove it, as needed.
            this.doctorsTableAdapter.Fill(this.floodReliefDataSet1.Doctors);
            // TODO: This line of code loads data into the 'floodReliefDataSet.MedicalCamps' table. You can move, or remove it, as needed.
            this.medicalCampsTableAdapter.Fill(this.floodReliefDataSet.MedicalCamps);
            WindowState = FormWindowState.Maximized;


            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.RowHeadersVisible = false;
            dataGridView3.BackgroundColor = Color.White;
            dataGridView3.RowHeadersVisible = false;
            var editButton = new DataGridViewButtonColumn();
            editButton.Name = "dataGridViewEditButton";
            editButton.HeaderText = "Edit";
            editButton.Text = "Edit";
            editButton.UseColumnTextForButtonValue = true;

            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;

            LoadMedicalCamps();
            dataGridView1.Columns.Add(editButton);
            dataGridView1.Columns.Add(deleteButton);

            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.RowHeadersVisible = false;
            var editButton2 = new DataGridViewButtonColumn();
            editButton2.Name = "dataGridViewEditButton2";
            editButton2.HeaderText = "Edit";
            editButton2.Text = "Edit";
            editButton2.UseColumnTextForButtonValue = true;

            var deleteButton2 = new DataGridViewButtonColumn();
            deleteButton2.Name = "dataGridViewDeleteButton2";
            deleteButton2.HeaderText = "Delete";
            deleteButton2.Text = "Delete";
            deleteButton2.UseColumnTextForButtonValue = true;

            LoadDoctors();

            dataGridView2.Columns.Add(editButton2);
            dataGridView2.Columns.Add(deleteButton2);

            dataGridView3.BackgroundColor = Color.White;
            dataGridView3.RowHeadersVisible = false;
            var editButton3 = new DataGridViewButtonColumn();
            editButton3.Name = "dataGridViewEditButton3";
            editButton3.HeaderText = "Edit";
            editButton3.Text = "Edit";
            editButton3.UseColumnTextForButtonValue = true;

            var deleteButton3 = new DataGridViewButtonColumn();
            deleteButton3.Name = "dataGridViewDeleteButton3";
            deleteButton3.HeaderText = "Delete";
            deleteButton3.Text = "Delete";
            deleteButton3.UseColumnTextForButtonValue = true;

            LoadPatients();

            
            dataGridView3.Columns.Add(deleteButton3);
            dataGridView3.Columns.Add(editButton3);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f2 = new Form1();
            f2.Show();
        }

       
        private void button4_Click(object sender, EventArgs e)
        {
            
            add_doctor f2 = new add_doctor();
            f2.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            
            add_camp f2 = new add_camp();
            f2.Show();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView2.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView2.Columns["dataGridViewDeleteButton2"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView2.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteDoctors(n);

                LoadDoctors();
                LoadMedicalCamps();
                LoadPatients();


            }
            
            else if (e.ColumnIndex == dataGridView2.Columns["dataGridViewEditButton2"].Index && e.RowIndex >= 0)
            {
                
                doctor_id.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                doc_fname.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                doc_lname.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                d_camid.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
                
                
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            addpatient f2 = new addpatient();
            f2.Show();
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
            if (e.RowIndex == dataGridView3.NewRowIndex)
                return;

            //Check if click is on specific column 
            else if (e.ColumnIndex == dataGridView3.Columns["dataGridViewDeleteButton3"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView3.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeletePatient(n);

                LoadDoctors();
                LoadMedicalCamps();
                LoadPatients();




            }
            else if (e.ColumnIndex == dataGridView3.Columns["dataGridViewEditButton3"].Index && e.RowIndex >= 0)
            {
                patient_id.Text = dataGridView3.CurrentRow.Cells[0].Value.ToString();
                patient_fname.Text = dataGridView3.CurrentRow.Cells[1].Value.ToString();
                patient_lname.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                p_camid.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();  
                p_disease.Text = dataGridView3.CurrentRow.Cells[4].Value.ToString();   
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            //if click is on new row or header row
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteMedicalCamp(n);

                LoadMedicalCamps();
                LoadDoctors();
                LoadPatients();

                

            }
            else if (e.ColumnIndex == dataGridView1.Columns["dataGridViewEditButton"].Index && e.RowIndex >= 0)
            {
                camp_id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                district_id.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                no_of_doc.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            }
        }

        private void patient_id_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void patient_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar));
        }

        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "FloodReliefSearchorUpdate";
            cm = new SqlCommand(sql, con);
            cm.CommandType = CommandType.StoredProcedure;
            cm.Parameters.AddWithValue("@mode", "Edit");
            cm.Parameters.AddWithValue("@patientID", Convert.ToInt32(patient_id.Text.Trim()));
            cm.Parameters.AddWithValue("@firstName", patient_fname.Text);
            cm.Parameters.AddWithValue("@LastName", patient_lname.Text);
            cm.Parameters.AddWithValue("@CampID", Convert.ToInt32(p_camid.Text.Trim()));
            cm.Parameters.AddWithValue("@Disease", p_disease.Text);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadDoctors();
            LoadMedicalCamps();
            LoadPatients();

            

        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "Select * from Patients where patientid like '%'+@patientid+'%' and \r\n\t\t   campid like '%'+@campid+'%' and disease like '%'+@disease+'%' and\r\n\t\t   firstname like '%'+@firstname+'%' and lastname like '%'+@lastname+'%' and campid in (select campid from MedicalCamps where districtid = @districtid)";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");
            cm.Parameters.AddWithValue("@patientID", patient_id.Text.Trim());
            cm.Parameters.AddWithValue("@firstName", patient_fname.Text);
            cm.Parameters.AddWithValue("@LastName", patient_lname.Text);
            cm.Parameters.AddWithValue("@CampID", p_camid.Text.Trim());
            cm.Parameters.AddWithValue("@Disease", p_disease.Text);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da4 = new SqlDataAdapter(cm);
            DataTable d4 = new DataTable();
            da4.Fill(d4);
            cm.Dispose();
            con.Close();
            dataGridView3.DataSource = null;
            //dataGridView3.Columns.Remove("dataGridViewDeleteButton3");
            //dataGridView3.Columns.Remove("dataGridViewEditButton3");
            
            dataGridView3.DataSource = d4;
            
        }

        private void button8_Click(object sender, EventArgs e)
        {
            LoadPatients();
            patient_id.Text = "";
            patient_fname.Text = "";
            patient_lname.Text = "";
            p_camid.Text = "";
            p_disease.Text = "";

        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "Select * from Doctors where doctorid like '%'+@doctorid+'%' and \r\n\t\t   campid like '%'+@campid+'%' and  firstname like '%'+@firstname+'%' and lastname like '%'+@lastname+'%' and campid in (select campid from MedicalCamps where districtid = @districtid)";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");
            cm.Parameters.AddWithValue("@doctorID", doctor_id.Text.Trim());
            cm.Parameters.AddWithValue("@firstName", doc_fname.Text);
            cm.Parameters.AddWithValue("@LastName", doc_lname.Text);
            cm.Parameters.AddWithValue("@CampID", d_camid.Text.Trim());
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);


            SqlDataAdapter da5 = new SqlDataAdapter(cm);
            DataTable d5 = new DataTable();
            da5.Fill(d5);
            cm.Dispose();
            con.Close();
            dataGridView2.DataSource = null;
            //dataGridView2.Columns.Remove("dataGridViewDeleteButton2");
            //dataGridView2.Columns.Remove("dataGridViewEditButton2");

            dataGridView2.DataSource = d5;
            
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoadDoctors();
            patient_id.Text = "";
            patient_fname.Text = "";
            patient_lname.Text = "";
            p_camid.Text = "";
            p_disease.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "Select * from MedicalCamps where campid like '%'+@campid+'%' and NoOfDoctors like '%'+@NoOfDoctors+'%' and districtid = @districtid";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");
            
            cm.Parameters.AddWithValue("@CampID", camp_id.Text.Trim());
            cm.Parameters.AddWithValue("@NoOfDoctors", no_of_doc.Text.Trim());
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);


            SqlDataAdapter da6 = new SqlDataAdapter(cm);
            DataTable d6 = new DataTable();
            da6.Fill(d6);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = null;
            //dataGridView1.Columns.Remove("dataGridViewDeleteButton");
            //dataGridView1.Columns.Remove("dataGridViewEditButton");

            dataGridView1.DataSource = d6;
            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            LoadMedicalCamps();
            camp_id.Text = "";
            no_of_doc.Text = "";
           
        }

        private void button10_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "UPDATE [dbo].[Doctors]\r\n   SET     ,[CampID] = @CampID>\r\n      ,[FirstName] = @FirstName>\r\n      ,[LastName] = @LastName\r\n WHERE doctorid=@DoctorID";
            cm = new SqlCommand(sql, con);
            
            cm.Parameters.AddWithValue("@CampID", Convert.ToInt32(d_camid.Text.Trim()));
            cm.Parameters.AddWithValue("@FirstName", doc_fname.Text);
            cm.Parameters.AddWithValue("@LastName", doc_lname.Text);
            cm.Parameters.AddWithValue("@DoctorID", Convert.ToInt32(doctor_id.Text.Trim()));
            
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadDoctors();
            LoadMedicalCamps();
            LoadPatients();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "UPDATE [dbo].[MedicalCamps]\r\n   SET      [DistrictID] = @districtid\r\n      ,[NoOfDoctors] = @NoOfDoctors\r\n WHERE campid=@campid";
            cm = new SqlCommand(sql, con);

            cm.Parameters.AddWithValue("@campid", Convert.ToInt32(camp_id.Text.Trim()));
            cm.Parameters.AddWithValue("@NoOfDoctors", Convert.ToInt32(no_of_doc.Text.Trim()));
            cm.Parameters.AddWithValue("@districtid", Convert.ToInt32(district_id.Text.Trim()));

            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadDoctors();
            LoadMedicalCamps();
            LoadPatients();
        }
    }
    

}
