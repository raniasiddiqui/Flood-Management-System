﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class d_inventory : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        private void LoadInventory()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            con.Open();
            string sql = "select * from Inventory where districtid =@districtid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = d;
        }

        private void LoadEssentials()
        {
            // TODO: Complete the function LoadOrders
            // SQL Query to Select all records from orders table in the descending order of order date
            con.Open();
            string sql = "select * from Essentials where inventoryid in(select inventoryid from Inventory where districtid = @districtid) and inventoryid = @inventoryid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@inventoryid", Convert.ToInt32(d_name.Text));
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da2 = new SqlDataAdapter(cm);
            DataTable d2 = new DataTable();
            da2.Fill(d2);
            cm.Dispose();
            con.Close();
            dataGridView2.DataSource = d2;


        }

        private void DeleteInventory(int inventoryid)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "Update Essentials set inventoryid = NULL where inventoryid = @inventoryid\r\n DELETE FROM Inventory WHERE districtid=@districtid";


            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            cm.Parameters.AddWithValue("@inventoryid", inventoryid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();

        }

        private void DeleteEssentials(int essentialid)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "DELETE FROM Essentials WHERE essentialid=@essentialid and inventoryid = @inventoryid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@essentialid", essentialid);
            cm.Parameters.AddWithValue("@inventoryid", Convert.ToInt32(d_name.Text));


            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();

        }


        public d_inventory()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f2 = new Form1();
            f2.Show();
        }

        private void d_inventory_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'floodReliefDataSet17.Inventory' table. You can move, or remove it, as needed.
            this.inventoryTableAdapter.Fill(this.floodReliefDataSet17.Inventory);
            WindowState = FormWindowState.Maximized;


            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;
            var editButton = new DataGridViewButtonColumn();
            editButton.Name = "dataGridViewEditButton";
            editButton.HeaderText = "Edit";
            editButton.Text = "Edit";
            editButton.UseColumnTextForButtonValue = true;

            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;

            LoadInventory();
            dataGridView1.Columns.Add(editButton);
            dataGridView1.Columns.Add(deleteButton);

            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.RowHeadersVisible = false;
            var editButton2 = new DataGridViewButtonColumn();
            editButton2.Name = "dataGridViewEditButton2";
            editButton2.HeaderText = "Edit";
            editButton2.Text = "Edit";
            editButton2.UseColumnTextForButtonValue = true;

            var deleteButton2 = new DataGridViewButtonColumn();
            deleteButton2.Name = "dataGridViewDeleteButton2";
            deleteButton2.HeaderText = "Delete";
            deleteButton2.Text = "Delete";
            deleteButton2.UseColumnTextForButtonValue = true;

            //LoadEssentials();

            dataGridView2.Columns.Add(editButton2);
            dataGridView2.Columns.Add(deleteButton2);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            // TODO: Complete the function DeleteMedicalCamp 
            // SQL query to Delete the from the order and order details table

            string sql = "INSERT INTO [dbo].[Inventory]\r\n           ([InventoryID]\r\n           ,[DistrictID])\r\n     VALUES\r\n           ((select max(InventoryID)+1 from Inventory)\r\n           ,@districtid)";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters

            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadInventory();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteInventory(n);

                LoadInventory();
                LoadEssentials();
                //LoadPatients();



            }
            else if (e.ColumnIndex == dataGridView1.Columns["dataGridViewEditButton"].Index && e.RowIndex >= 0)
            {
                d_name.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                //district_id.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                // no_of_doc.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                LoadInventory();
                LoadEssentials();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            add_essential f2 = new add_essential();
            f2.Show();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView2.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView2.Columns["dataGridViewDeleteButton2"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView2.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteEssentials(n);

                LoadEssentials();
                LoadInventory();


            }

            else if (e.ColumnIndex == dataGridView2.Columns["dataGridViewEditButton2"].Index && e.RowIndex >= 0)
            {

                E_name.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                Quantity_inven.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();

                LoadEssentials();
                LoadInventory();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                con.Open();
                string sql = "Select * from Inventory where inventoryid like '%'+@inventoryid+'%' and districtid = @districtid";
                cm = new SqlCommand(sql, con);
                

                cm.Parameters.AddWithValue("@DistrictID", Global.GlobalVar);
                cm.Parameters.AddWithValue("@InventoryID", d_name.Text);



                SqlDataAdapter da6 = new SqlDataAdapter(cm);
                DataTable d6 = new DataTable();
                da6.Fill(d6);
                cm.Dispose();
                con.Close();
                dataGridView1.DataSource = null;
                //dataGridView1.Columns.Remove("dataGridViewDeleteButton");
                //dataGridView1.Columns.Remove("dataGridViewEditButton");

                dataGridView1.DataSource = d6;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {

            con.Open();
            //string sql = "Select * from ShelterHomes where shelterid like '%'+@shelterid+'%' and \r\n\t\t   NoOfPeople like '%'+@NoOfPeople+'%' and capacity like '%'+@capacity+'%' and districtid = @districtid";
            string sql = "Select * from Essentials where essentialname like '%'+@essentialname+'%' and \r\n\t\t   quantity like '%'+@quantity+'%' ";
                //"and inventoryid in(select inventoryid from inventory where districtid=@districtid)";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");

            cm.Parameters.AddWithValue("@essentialname", E_name.Text.Trim());
            
            cm.Parameters.AddWithValue("@quantity", Quantity_inven.Text.Trim());
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);


            SqlDataAdapter da5 = new SqlDataAdapter(cm);
            DataTable d5 = new DataTable();
            da5.Fill(d5);
            cm.Dispose();
            con.Close();
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = d5;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            d_name.Text = "";
            LoadInventory();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            E_name.Text = "";
            Quantity_inven.Text = "";
            LoadEssentials();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "UPDATE [dbo].[Essentials]\r\n   SET     [Quantity] = @Quantity\r\n WHERE InventoryID=@InventoryID    and essentialname=@essentialname";
            cm = new SqlCommand(sql, con);

            cm.Parameters.AddWithValue("@EssentialName", E_name.Text.Trim());
            cm.Parameters.AddWithValue("@Inventoryid", Convert.ToInt32(d_name.Text));
            //cm.Parameters.AddWithValue("@LastName", doc_lname.Text);
            cm.Parameters.AddWithValue("@Quantity", Convert.ToInt32(Quantity_inven.Text));

            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadEssentials();
            LoadInventory();
            //LoadPatients();
        }
    }
}
