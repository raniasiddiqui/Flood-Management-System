﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Flood_relief
{
    public partial class d_family : Form
    {
        const string constr = @"Data Source=DESKTOP-PORORBA;Initial Catalog=FloodRelief;User ID=sa;Password=skahwa123; Integrated Security=SSPI";
        SqlConnection con = new SqlConnection(constr);
        SqlCommand cm = new SqlCommand();
        public d_family()
        {
            InitializeComponent();
        }
        private void DeleteFamily(int familyid)
        {
            con.Open();


            string sql = "DELETE FROM CashReq WHERE familyid=@familyid        DELETE FROM Families WHERE familyid=@familyid";
            cm = new SqlCommand(sql, con);

            // Specify the value of the parameters
            cm.Parameters.AddWithValue("@familyid", familyid);
            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
        }

        private void LoadFamilies()
        {
            con.Open();
            string sql = "select FamilyID,ShelterID,LivingConditions from Families where districtid =@districtid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = d;
        }

        private void LoadFamilyLosses()
        {
            con.Open();
            string sql = "* from FamilyLosses where familyid =@familyid";
            cm = new SqlCommand(sql, con);
            cm.Parameters.AddWithValue("@familyid", family_id);
            SqlDataAdapter da = new SqlDataAdapter(cm);
            DataTable d = new DataTable();
            da.Fill(d);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = d;
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 f2 = new Form1();
            f2.Show();
        }

        private void d_family_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'floodReliefDataSet16.FamilyLosses' table. You can move, or remove it, as needed.
            this.familyLossesTableAdapter.Fill(this.floodReliefDataSet16.FamilyLosses);
            // TODO: This line of code loads data into the 'floodReliefDataSet15.Families' table. You can move, or remove it, as needed.
            this.familiesTableAdapter.Fill(this.floodReliefDataSet15.Families);
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.RowHeadersVisible = false;

            

            var editButton = new DataGridViewButtonColumn();
            editButton.Name = "dataGridViewEditButton";
            editButton.HeaderText = "Edit";
            editButton.Text = "Edit";
            editButton.UseColumnTextForButtonValue = true;

            var deleteButton = new DataGridViewButtonColumn();
            deleteButton.Name = "dataGridViewDeleteButton";
            deleteButton.HeaderText = "Delete";
            deleteButton.Text = "Delete";
            deleteButton.UseColumnTextForButtonValue = true;

            var editButton2 = new DataGridViewButtonColumn();
            editButton2.Name = "dataGridViewEditButton2";
            editButton2.HeaderText = "Edit";
            editButton2.Text = "Edit";
            editButton2.UseColumnTextForButtonValue = true;

            var deleteButton2 = new DataGridViewButtonColumn();
            deleteButton2.Name = "dataGridViewDeleteButton2";
            deleteButton2.HeaderText = "Delete";
            deleteButton2.Text = "Delete";
            deleteButton2.UseColumnTextForButtonValue = true;

            LoadFamilies();
            dataGridView1.Columns.Add(editButton);
            dataGridView1.Columns.Add(deleteButton);


        }

        private void button3_Click(object sender, EventArgs e)
        {
            add_family f2 = new add_family();
            f2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == dataGridView1.NewRowIndex || e.RowIndex < 0)
                return;

            //Check if click is on specific column 
            if (e.ColumnIndex == dataGridView1.Columns["dataGridViewDeleteButton"].Index && e.RowIndex >= 0)
            {
                var data = dataGridView1.Rows[e.RowIndex];
                MessageBox.Show(data.Cells[0].Value.ToString());

                int n = (int)data.Cells[0].Value;
                DeleteFamily(n);
                LoadFamilies();




            }
            else if (e.ColumnIndex == dataGridView1.Columns["dataGridViewEditButton"].Index && e.RowIndex >= 0)
            {
                family_id.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                shelter_id.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                string s = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                if (string.Compare(s,"1") == 0)
                {
                    radioButton1.Checked = true;
                }
                else if (string.Compare(s, "2") == 0)
                {
                    radioButton5.Checked = true;
                }
                else if (string.Compare(s, "3") == 0)
                {
                    radioButton4.Checked = true;
                }
                else if (string.Compare(s, "4") == 0)
                {
                    radioButton3.Checked = true;
                }
                else if (string.Compare(s, "5") == 0)
                {
                    radioButton2.Checked = true;
                }
                //capacity.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "Select FamilyID,ShelterID,LivingConditions from Families where familyid like '%'+@familyid+'%' and \r\n\t\t   ShelterID like '%'+@ShelterID+'%' and LivingConditions like '%'+@LivingConditions+'%' and districtid = @districtid";
            cm = new SqlCommand(sql, con);
            //cm.CommandType = CommandType.StoredProcedure;
            //cm.Parameters.AddWithValue("@mode", "Search");
            cm.Parameters.AddWithValue("@familyid", family_id.Text.Trim());
            cm.Parameters.AddWithValue("@shelterid", shelter_id.Text);
            cm.Parameters.AddWithValue("@LivingConditions", Global.GlobalVar2);
            cm.Parameters.AddWithValue("@districtid", Global.GlobalVar);

            SqlDataAdapter da4 = new SqlDataAdapter(cm);
            DataTable d4 = new DataTable();
            da4.Fill(d4);
            cm.Dispose();
            con.Close();
            dataGridView1.DataSource = null;
            //dataGridView3.Columns.Remove("dataGridViewDeleteButton3");
            //dataGridView3.Columns.Remove("dataGridViewEditButton3");

            dataGridView1.DataSource = d4;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar2 = "1";
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar2 = "2";
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar2 = "3";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar2 = "4";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Global.GlobalVar2 = "5";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            shelter_id.Text = "";
            family_id.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
            radioButton3.Checked = false;
            radioButton4.Checked = false;
            radioButton5.Checked = false;
            LoadFamilies();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            con.Open();
            string sql = "UPDATE [dbo].[Families]\r\n   SET \r\n           [ShelterID] = @shelterid\r\n      ,[LivingConditions] = @livingconditions\r\n WHERE [FamilyID] = @familyid";
            cm = new SqlCommand(sql, con);

            cm.Parameters.AddWithValue("@shelterid", Convert.ToInt32(shelter_id.Text.Trim()));
            cm.Parameters.AddWithValue("@familyid", Convert.ToInt32(family_id.Text.Trim()));
            cm.Parameters.AddWithValue("LivingConditions", Convert.ToInt32(Global.GlobalVar2));

            cm.ExecuteNonQuery();
            cm.Dispose();
            con.Close();
            LoadFamilies();
        }
    }
    }

